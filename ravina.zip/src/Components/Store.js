export default function Store(){
    return(
        <>
        <div className="container cn">
        <div>
       <div className="subscribeNew">
                <div className="container">
                <div className="mainContentsub">
                  <div className="subCribeDiv2">
<img className='sunglasses'  src='/assets/images/Capture.PNG'/>
        
    </div>
    </div>
    </div>
    </div>
    </div>
    <div className="popl">
        <div className=" deal ">
                <div className=" the">Popular Membership</div>
                <div className="of "></div>
            </div>           
            <div className="start" >
                <div className="summ" >
                    <div className="rdy" >
                        <div className="rs" ></div>
                        <img width={" 420px"} height= {"420px"}  left = {"0px"}  top= {"0px"}  position= {'absolute'}  src="/assets/images/sale.png" />
                    </div>
                    <div className="rdy" >
                        <div className="rs" ></div>
                        <img width={" 420px"} height= {"420px"}  left = {"0px"}  top= {"0px"}  position= {'absolute'}  src="/assets/images/zon.png" />
                    </div>
                </div>
                <div className="rumi" >
                    <div className="rssb">
                        <div className="org"></div>
                        <img width={" 420px"} height= {"420px"}  left = {"0px"}  top= {"0px"}  position= {'absolute'} src="/assets/images/food.png" />
                    </div>
                    <div className="rssb">
                        <div className="org"></div>
                        <img width={" 420px"} height= {"420px"}  left = {"0px"}  top= {"0px"}  position= {'absolute'} src="/assets/images/sun.png" />
                    </div>
                </div>
            </div>

            </div>

        </div><br/><br/><br/><br/>
        </>
    )
}