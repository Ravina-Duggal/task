export default function Coupon(){
    return(
        <> 
        <div className="container-fluid ">
         
            <div className="navi" >
                <div className="cupn text-center" >Coupon By Categories</div><br/>
                <div className="bck" ></div>
            </div>
            <div className="man" >
                <div className="del">
                    <div className="fshn">
                        <img width= {"36px"} height={"36px"} src="/assets/images/fashn.png" />
                        <div className="wrd">Beauty</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/ramen.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/makeup.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/toys.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/server.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/game.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/phone.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/travel.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                    <div className="fshn" >
                        <img width= {"36px"} height= {"36px"} src="/assets/images/movies.png" />
                        <div className="wrd">Fashion</div>
                    </div>
                </div>
                <div  className="name">
                    <div className="lex">
                        <div className="cat" >
                            <div className="lux">
                                <img width={" 80px"} height={"24px"}  src="/assets/images/amazon.png" />
                                <div className="rav" >Amazon</div>
                            </div>
                            <div className="ravu">
                                <div className="bibo">Flat 30% Off</div>
                                <div className="rab">
                                    <div className="rabi">Grab Now</div>
                                </div>
                            </div>
                        </div>
                        <div className="cat" >
                            <div className="lux">
                                <img width={" 80px"} height={"24px"}  src="/assets/images/amazon.png" />
                                <div className="rav" >Amazon</div>
                            </div>
                            <div className="ravu">
                                <div className="bibo">Flat 30% Off</div>
                                <div className="rab">
                                    <div className="rabi">Grab Now</div>
                                </div>
                            </div>
                        </div>
                        <div className="cat" >
                            <div className="lux">
                                <img width={" 80px"} height={"24px"}  src="/assets/images/amazon.png" />
                                <div className="rav" >Amazon</div>
                            </div>
                            <div className="ravu">
                                <div className="bibo">Flat 30% Off</div>
                                <div className="rab">
                                    <div className="rabi">Grab Now</div>
                                </div>
                            </div>
                        </div>
                        <div className="cat" >
                            <div className="lux">
                                <img width={" 80px"} height={"24px"}  src="/assets/images/amazon.png" />
                                <div className="rav" >Amazon</div>
                            </div>
                            <div className="ravu">
                                <div className="bibo">Flat 30% Off</div>
                                <div className="rab">
                                    <div className="rabi">Grab Now</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> </div><br/><br/>

        </>
    )
}