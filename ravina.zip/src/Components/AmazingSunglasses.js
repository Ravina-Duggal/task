import React from 'react'
export default function AmazingSunglasses() {
  return (
    <div>
       <div className="subscribeNew">
                <div className="container">
                <div className="mainContentsub">
                  <div className="subCribeDiv2">
<img className='sunglasses'  src='/assets/images/Capture.PNG'/>
        
    </div>
    </div>
    </div>
    </div>
    </div>
  )
}
