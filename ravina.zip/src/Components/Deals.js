export default function Deals(){
    return(
        <>
        <div className="container">
        <div className=" deal" >
                        <div className=" the">Deals Of The Day</div>
                        <div className=" of "></div>
                    </div>
        <div className="row mt-3 g-4">
             <div className="col-lg-3">
               <div className="maincardWraper">
                 <div className="cardWraperBody">
                     <img width = {"80px"} height={"20px"} src="/assets/images/amazon.png" />
                     <p>Amazon</p>
                     <div className="cardWrapercont rap">Flat 30% off</div>
                 </div>
                 <div className="cardWraperfoot">
                     <div className="cardWraperbtn">Grab now</div>
                 </div>
             </div>
             </div>
             <div className="col-lg-3">
               <div className="maincardWraper">
                 <div className="cardWraperBody">
                     <img width = {"80px"} height={"20px"} src="/assets/images/amazon.png" />
                     <p>Amazon</p>
                     <div className="cardWrapercont rap">Flat 30% off</div>
                 </div>
                 <div className="cardWraperfoot">
                     <div className="cardWraperbtn">Grab now</div>
                 </div>
             </div>
             </div>
             <div className="col-lg-3">
               <div className="maincardWraper">
                 <div className="cardWraperBody">
                     <img width = {"80px"} height={"20px"} src="/assets/images/amazon.png" />
                     <p>Amazon</p>
                     <div className="cardWrapercont rap">Flat 30% off </div>
                 </div>
                 <div className="cardWraperfoot">
                     <div className="cardWraperbtn">Grab now</div>
                 </div>
             </div>
             </div>
             <div className="col-lg-3">
               <div className="maincardWraper">
                 <div className="cardWraperBody">
    
                     <img width = {"80px"} height={"20px"} src="/assets/images/amazon.png" />
                     <p>Amazon</p>
                     <div className="cardWrapercont rap">Flat 30% off </div>
                 </div>
                 <div className="cardWraperfoot">
                     <div className="cardWraperbtn">Grab now</div>
                 </div>
             </div>
             </div>
           </div>
           </div><br/><br/>
        </>
    )
}